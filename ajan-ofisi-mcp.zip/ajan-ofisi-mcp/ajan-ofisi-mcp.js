#!/usr/bin/env node
// Ajan Ofisi MCP sunucusu: bağımlılık yok, sadece Node.js 18+
// Claude bu araçlarla ofisi yönetir: ajanları listeler, görev verir, geçmişe bakar.
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const DIR = __dirname, CFG = JSON.parse(fs.readFileSync(path.join(DIR, 'ofis.config.json'), 'utf8'));
const VERI = path.join(DIR, 'veri', 'gorevler.json');
const abs = p => path.resolve(DIR, p);
const yasak = k => (CFG.yasakKlasorler || []).some(y => abs(k).startsWith(abs(y)));
fs.mkdirSync(path.join(DIR, 'veri'), { recursive: true });
const gecmis = () => { try { return JSON.parse(fs.readFileSync(VERI, 'utf8')); } catch { return []; } };
const kaydet = g => fs.writeFileSync(VERI, JSON.stringify(g, null, 2));

// Her çalışana klasör ve CLAUDE.md hazırla (yoksa)
for (const c of CFG.calisanlar) {
  if (yasak(c.klasor)) { console.error('Yasak klasör: ' + c.id); process.exit(1); }
  fs.mkdirSync(abs(c.klasor), { recursive: true });
  const f = path.join(abs(c.klasor), 'CLAUDE.md');
  if (!fs.existsSync(f)) fs.writeFileSync(f, `# ${c.rol}\n${c.aciklama}\n\n## Kurallar\n${c.kurallar}\n`);
}

const OFIS_KURALI = c => `Sen ${CFG.ofis.ad} ofisinde ${c.rol} olarak çalışıyorsun. Patronun ${CFG.ofis.patron}.
Bulunduğun klasördeki CLAUDE.md bu işin kurallarıdır; ona sadık kal.
YASAK: hiçbir şeyi yayınlama, paylaşma, mesaj veya e-posta gönderme, ödeme veya sipariş yapma, canlı veritabanına yazma, mevcut dosyaları silme. Gerekirse taslağını hazırla ve raporda "onay gerekiyor" yaz.
Bitirince kısa rapor yaz: ne yapıldı, dosyalar nerede, onay bekleyen ne var.`;

function claude(args, cwd, girdi) {
  return new Promise((ok, hata) => {
    const env = { ...process.env };
    for (const k of Object.keys(env)) if (k === 'CLAUDECODE' || k.startsWith('CLAUDE_CODE_')) delete env[k];
    const p = spawn(CFG.claudeYolu, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'] });
    let o = '', e = '';
    const t = setTimeout(() => { p.kill(); hata(new Error('Zaman aşımı (10 dk)')); }, 600000);
    p.stdout.on('data', d => o += d); p.stderr.on('data', d => e += d);
    p.on('error', x => { clearTimeout(t); hata(new Error('claude başlatılamadı: ' + x.message)); });
    p.on('close', () => { clearTimeout(t); try { ok(JSON.parse(o)); } catch { hata(new Error((e || o || 'Boş çıktı').slice(0, 500))); } });
    p.stdin.end(girdi);
  });
}
const MCPYOK = ['--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}'];

async function calistir(id, gorev, onceki) {
  const c = CFG.calisanlar.find(x => x.id === id);
  if (!c) throw new Error('Böyle bir çalışan yok: ' + id);
  const r = await claude(['-p', '--output-format', 'json', '--model', c.model, '--permission-mode', 'acceptEdits',
    '--allowedTools', c.araclar.join(','), '--append-system-prompt', OFIS_KURALI(c), ...MCPYOK],
    abs(c.klasor), gorev + (onceki ? '\n\nÖnceki çalışanın raporu:\n' + onceki.slice(0, 4000) : ''));
  return { rapor: String(r.result || ''), oturum: r.session_id || '' };
}

async function planla(gorev) {
  const liste = CFG.calisanlar.map(c => `- ${c.id}: ${c.rol}. ${c.aciklama}`).join('\n');
  const sys = `Sen Ana Beyin'sin (genel müdür). İş yapmazsın, sadece plan çıkarırsın. Çalışanlar:\n${liste}\n` +
    `En az adım kullan. Çoğu iş tek çalışana gider; zincir sadece çıktı gerçekten lazımsa kurulur. Oyun: kod sonra arayuz. Web sitesi: web, arayuz, kod. ` +
    `Sadece şu JSON'u döndür: {"ozet":"tek cümle","adimlar":[{"birim":"id","gorev":"net talimat"}]}`;
  const r = await claude(['-p', '--output-format', 'json', '--model', CFG.genelMudur.model, '--tools', '', '--no-session-persistence', '--system-prompt', sys, ...MCPYOK], DIR, gorev);
  const j = JSON.parse(String(r.result).match(/\{[\s\S]*\}/)[0]);
  j.adimlar = j.adimlar.filter(a => CFG.calisanlar.some(c => c.id === a.birim));
  if (!j.adimlar.length) throw new Error('Plan boş');
  return j;
}

function dosyala(no, gorev, adimlar) {
  const g = gecmis(), t = new Date().toISOString().slice(0, 10), d = path.join(DIR, 'ofis-ciktilari', `${t}-${no}`);
  fs.mkdirSync(d, { recursive: true });
  adimlar.forEach(a => fs.writeFileSync(path.join(d, a.birim + '.md'), a.rapor));
  g.push({ no, tarih: new Date().toISOString(), gorev, adimlar: adimlar.map(a => ({ birim: a.birim, oturum: a.oturum })), klasor: d });
  kaydet(g); return d;
}
const yeniNo = () => gecmis().length + 1;

const ARACLAR = [
  { name: 'ofis_ajanlari', description: 'Ofisteki ajanları, ekiplerini ve ne iş yaptıklarını listeler.', inputSchema: { type: 'object', properties: {} },
    fn: async () => CFG.calisanlar.map(c => `${c.id} | ${c.rol} | ${c.ekip} | model: ${c.model} | ${c.aciklama}`).join('\n') },
  { name: 'gorev_ver', description: 'Doğrudan tek bir ajana görev verir (Ana Beyin atlanır, daha az token). Ajan kendi klasöründe çalışır ve rapor verir.',
    inputSchema: { type: 'object', properties: { ajan: { type: 'string', description: 'kod, arayuz, web veya muh' }, gorev: { type: 'string' } }, required: ['ajan', 'gorev'] },
    fn: async ({ ajan, gorev }) => { const no = yeniNo(), r = await calistir(ajan, gorev); const d = dosyala(no, gorev, [{ birim: ajan, ...r }]); return `Rapor (görev ${no}, ${ajan}):\n${r.rapor}\n\nKayıt: ${d}`; } },
  { name: 'ana_beyin_gorev', description: 'Görevi Ana Beyin\'e verir. Önce düşünüp plan çıkarır, sonra uygun ajanlara sırayla dağıtır ve sonuçları toplar.',
    inputSchema: { type: 'object', properties: { gorev: { type: 'string' } }, required: ['gorev'] },
    fn: async ({ gorev }) => { const no = yeniNo(), pl = await planla(gorev), ad = []; let onceki = '';
      for (const a of pl.adimlar) { const r = await calistir(a.birim, a.gorev, onceki); onceki = r.rapor; ad.push({ birim: a.birim, ...r }); }
      const d = dosyala(no, gorev, ad);
      return `Plan: ${pl.ozet}\n\n` + ad.map(a => `## ${a.birim}\n${a.rapor}`).join('\n\n') + `\n\nKayıt: ${d}`; } },
  { name: 'gorev_gecmisi', description: 'Son görevleri ve oturum numaralarını gösterir (claude --resume ile devam edilebilir).', inputSchema: { type: 'object', properties: {} },
    fn: async () => gecmis().slice(-10).map(g => `#${g.no} ${g.tarih} | ${g.gorev} | ${g.adimlar.map(a => a.birim + ':' + a.oturum).join(', ')} | ${g.klasor}`).join('\n') || 'Henüz görev yok.' }
];

// --- MCP (stdio, JSON-RPC) ---
const yaz = o => process.stdout.write(JSON.stringify(o) + '\n');
async function isle(m) {
  const { id, method, params } = m;
  if (id === undefined) return; // bildirim
  try {
    if (method === 'initialize') return yaz({ jsonrpc: '2.0', id, result: { protocolVersion: params?.protocolVersion || '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'ajan-ofisi', version: '1.0.0' } } });
    if (method === 'ping') return yaz({ jsonrpc: '2.0', id, result: {} });
    if (method === 'tools/list') return yaz({ jsonrpc: '2.0', id, result: { tools: ARACLAR.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })) } });
    if (method === 'tools/call') {
      const a = ARACLAR.find(x => x.name === params.name);
      if (!a) return yaz({ jsonrpc: '2.0', id, error: { code: -32602, message: 'Araç yok' } });
      try { const t = await a.fn(params.arguments || {}); return yaz({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: t }] } }); }
      catch (e) { return yaz({ jsonrpc: '2.0', id, result: { isError: true, content: [{ type: 'text', text: 'Hata: ' + e.message }] } }); }
    }
    yaz({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Bilinmeyen yöntem' } });
  } catch (e) { yaz({ jsonrpc: '2.0', id, error: { code: -32603, message: e.message } }); }
}
let tampon = '';
process.stdin.on('data', d => { tampon += d; let i; while ((i = tampon.indexOf('\n')) >= 0) { const s = tampon.slice(0, i).trim(); tampon = tampon.slice(i + 1); if (s) { try { isle(JSON.parse(s)); } catch {} } } });
