# Ajan Ofisi MCP

Claude'a ofisi araç olarak açan, bağımlılığı olmayan MCP sunucusu (Node.js 18+).

## Araçlar
- `ofis_ajanlari`: ajanları listeler
- `ana_beyin_gorev`: Ana Beyin plan yapar, ajanlar sırayla çalışır
- `gorev_ver`: doğrudan tek ajana görev verir
- `gorev_gecmisi`: son görevleri gösterir

## Kurulum (Claude Code kurulu bir bilgisayarda ya da GitHub Codespaces'te)
```
git clone <bu-repo>
cd <repo>
claude mcp add ajan-ofisi -- node ajan-ofisi-mcp.js
```
Ajanlar `ofis.config.json` dosyasından okunur. Yeni ajan eklemek için o dosyaya bir çalışan ekle.

## Güvenlik
Ajanlara Bash verilmez. Yayınlama, mesaj gönderme, ödeme ve dosya silme yasaktır.
`yasakKlasorler` listesindeki klasörlere dokunulmaz. Şifre ve token'ları bu repoya yazma.
