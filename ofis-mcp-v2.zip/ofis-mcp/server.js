import express from "express";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { talimat, AJANLAR } from "./ofis.js";

const KOK = path.dirname(fileURLToPath(import.meta.url));
const CIKTI = path.join(KOK, "ofis-ciktilari");
const AYAR = path.join(KOK, "ayar.json");
const PORT = Number(process.env.PORT || 4747);
fs.mkdirSync(CIKTI, { recursive: true });

// Gizli anahtar: ilk açılışta üretilir, adresin içinde yer alır.
let ayar = {};
try { ayar = JSON.parse(fs.readFileSync(AYAR, "utf8")); } catch {}
if (!ayar.anahtar) { ayar.anahtar = crypto.randomBytes(16).toString("hex"); fs.writeFileSync(AYAR, JSON.stringify(ayar, null, 2)); }
const ANAHTAR = ayar.anahtar;
const GOREV = path.join(KOK, "gorevler.json");
const gorevOku = () => { try { return JSON.parse(fs.readFileSync(GOREV, "utf8")); } catch { return {}; } };

// Güvenli yol: her şey sadece ofis-ciktilari içinde kalır.
function guvenliYol(goreli) {
  const temiz = String(goreli || "").replace(/\\/g, "/").split("/").filter(p => p && p !== "." && p !== "..").join("/");
  const tam = path.join(CIKTI, temiz);
  if (!tam.startsWith(CIKTI)) throw new Error("Geçersiz yol");
  return tam;
}
const metin = (t) => ({ content: [{ type: "text", text: t }] });

function sunucuOlustur() {
  const s = new McpServer({ name: "dijital-ofis", version: "1.0.0" });

  s.tool("ofis_baslat", "Ofisi başlatır: Yönetici talimatını, ajan listesini ve Patron'un belirlediği görevleri verir. Kullanıcı 'ofisi başlat' dediğinde veya bir ofis görevi verdiğinde ilk bunu çağır.", {},
    async () => metin(talimat(gorevOku())));

  s.tool("ajan_listesi", "Ofisteki departmanları, ajanları ve görevlerini listeler.", {},
    async () => { const g = gorevOku(); return metin(AJANLAR.map(a => `${a.id}: ${a.ad} (${a.dept}) - ${g[a.id] || "görev yok"}`).join("\n")); });

  s.tool("gorev_tanimla", "Patron'un söylediği bir ajanın görev tanımını kaydeder (sadece Patron söyleyince çağır, kendin uydurma).",
    { ajan_id: z.string().describe("oyun, web, icerikci, sosyal, avci, ses, youtube, video, mentalite veya yonetici"), gorev: z.string() },
    async ({ ajan_id, gorev }) => {
      if (!AJANLAR.some(a => a.id === ajan_id)) return metin("Böyle bir ajan yok: " + ajan_id);
      const g = gorevOku(); g[ajan_id] = gorev.slice(0, 2000);
      fs.writeFileSync(GOREV, JSON.stringify(g, null, 2), "utf8");
      return metin("Görev kaydedildi: " + ajan_id);
    });

  s.tool("cikti_kaydet", "Bir ajanın ürettiği dosyayı ofis-ciktilari klasörüne kaydeder. Mevcut dosyanın üzerine yazmaz.",
    { klasor: z.string().describe("Alt klasör, örn. 2026-11-17-uzay-animasyonu veya efektler-kurgu-icin"),
      dosya_adi: z.string().describe("Örn. fikirler.md veya index.html"),
      icerik: z.string(), ajan: z.string().optional() },
    async ({ klasor, dosya_adi, icerik, ajan }) => {
      const yol = guvenliYol(path.join(klasor, dosya_adi));
      fs.mkdirSync(path.dirname(yol), { recursive: true });
      if (fs.existsSync(yol)) return metin("Bu dosya zaten var, başka bir ad kullan: " + dosya_adi);
      fs.writeFileSync(yol, icerik, "utf8");
      return metin(`Kaydedildi${ajan ? " (" + ajan + ")" : ""}: ${path.relative(CIKTI, yol)}`);
    });

  s.tool("cikti_listele", "ofis-ciktilari içindeki dosyaları listeler.",
    { klasor: z.string().optional() },
    async ({ klasor }) => {
      const kok = guvenliYol(klasor || "");
      const sonuc = [];
      const gez = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name); e.isDirectory() ? gez(p) : sonuc.push(path.relative(CIKTI, p)); } };
      if (fs.existsSync(kok)) gez(kok);
      return metin(sonuc.length ? sonuc.slice(0, 200).join("\n") : "Henüz dosya yok.");
    });

  s.tool("cikti_oku", "ofis-ciktilari içindeki bir dosyayı okur (örn. Kurgu, Efekt'in teslim ettiğini okur).",
    { yol: z.string() },
    async ({ yol }) => {
      const p = guvenliYol(yol);
      if (!fs.existsSync(p) || fs.statSync(p).isDirectory()) return metin("Dosya bulunamadı.");
      return metin(fs.readFileSync(p, "utf8").slice(0, 60000));
    });

  s.tool("rapor_yaz", "Görev raporunu kaydeder (raporlar klasörü). Her görev sonunda çağır.",
    { gorev: z.string(), rapor: z.string() },
    async ({ gorev, rapor }) => {
      const tarih = new Date().toISOString().slice(0, 10);
      const slug = gorev.toLowerCase().replace(/[^a-z0-9ğüşıöç]+/gi, "-").slice(0, 40) || "gorev";
      let ad = `raporlar/${tarih}-${slug}.md`, i = 2;
      while (fs.existsSync(guvenliYol(ad))) ad = `raporlar/${tarih}-${slug}-${i++}.md`;
      fs.mkdirSync(path.dirname(guvenliYol(ad)), { recursive: true });
      fs.writeFileSync(guvenliYol(ad), `# ${gorev}\n\n${rapor}\n`, "utf8");
      return metin("Rapor kaydedildi: " + ad);
    });

  return s;
}

const app = express();
app.use(express.json({ limit: "5mb" }));

app.post(`/mcp/${ANAHTAR}`, async (req, res) => {
  try {
    const server = sunucuOlustur();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    res.on("close", () => { transport.close(); server.close(); });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (e) {
    if (!res.headersSent) res.status(500).json({ jsonrpc: "2.0", error: { code: -32603, message: "Sunucu hatası" }, id: null });
  }
});
const yok = (req, res) => res.status(405).json({ jsonrpc: "2.0", error: { code: -32000, message: "Method not allowed" }, id: null });
app.get(`/mcp/${ANAHTAR}`, yok);
app.delete(`/mcp/${ANAHTAR}`, yok);
app.use((req, res) => res.status(404).send("Bulunamadı"));

app.listen(PORT, "127.0.0.1", () => {
  console.log("\n✅ Dijital Ofis MCP çalışıyor.");
  console.log("Yerel adres: http://127.0.0.1:" + PORT + "/mcp/" + ANAHTAR);
  console.log("\nSonraki adım: tünel aç, çıkan https adresinin sonuna /mcp/" + ANAHTAR + " ekle.\n");
});
