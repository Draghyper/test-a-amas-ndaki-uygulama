# Dijital Ofis MCP v2 - Guncelleme (yeni ajan listesi)

ESKI SUNUCUN CALISIYORSA (ayni adres kalsin istiyorsan):
1. Calisan sunucuyu kapat (terminalde Ctrl+C).
2. Zip'i eski ofis-mcp klasorunun USTUNE ac:  unzip -o ofis-mcp-v2.zip -d ~
   (ayar.json zip'te yok; gizli anahtarin ve baglayici adresin degismez.)
3. Klasore gir:  cd ~/ofis-mcp   ve   npm install
4. Sunucuyu tekrar baslat:  node server.js
5. Tunel kapaliysa yeniden ac:  cloudflared tunnel --url http://127.0.0.1:4747
   Tunel adresi degisirse Claude'daki baglayiciyi yeni adresle guncelle.

YENI KURULUMSA: unzip ofis-mcp-v2.zip -d ~ ; cd ~/ofis-mcp ; npm install ; node server.js

Yeni araç: gorev_tanimla. Sohbette "Video Editor'un gorevi su: ..." dersen Yonetici kaydeder.
Ajan gorevleri bos baslar, Patron belirler.
