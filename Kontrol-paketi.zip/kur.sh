#!/usr/bin/env bash
# Kontrol ajanını Linux'a kurar (bağımlılıklar + ikili + servis).
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Bu betiği root olarak çalıştırın: sudo ./kur.sh"
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="kontrol-linux-amd64"

echo "== 1/4) paket bağımlılıkları =="
if command -v apt-get >/dev/null; then
  apt-get update -qq
  apt-get install -y -qq ffmpeg xdotool
elif command -v dnf >/dev/null; then
  dnf install -y ffmpeg xdotool
elif command -v pacman >/dev/null; then
  pacman -S --noconfirm ffmpeg xdotool
else
  echo "Paket yöneticisi bulunamadı. Elle kurun: ffmpeg, xdotool"
fi

echo "== 2/4) ajan kuruluyor =="
install -m 755 "$HERE/dist/$BIN" /usr/local/bin/kontrol

echo "== 3/4) Google kimlik bilgileri =="
kontrol setup

echo "== 4/4) Google hesabı bağlanıyor =="
kontrol login || echo "Google girişi atlandı (kodla eşleştirme kullanabilirsiniz)."

echo
echo "Kontrol kuruldu. Başlatmak için:"
echo "  kontrol serve"
echo
echo "Eşleştirme kodunuzu görmek için: kontrol pair"
