# Kontrol — Kendi bilgisayarınızı telefonunuzdan uzaktan kontrol edin

Kontrol, **kendi** bilgisayarınızı **kendi** telefonunuzdan yönetmek için yazılmış, kendi sunucunuzda çalışan bir uzaktan kontrol aracıdır. Chrome Remote Desktop / RustDesk mantığıyla çalışır, ama aracı katmanı yoktur: sunucu sizindir, veri sizin makinenizde kalır.

| Teslimat | Dosya | Ne işe yarar |
|---|---|---|
| Android uygulaması | `dist/Kontrol.apk` | Telefondaki **kontrolör** (dokunmatik ekran + klavye + dosya + terminal) |
| Windows ajanı | `dist/kontrol-windows-amd64.exe` | Kontrol edilen **Windows** bilgisayarında çalışan ajan |
| Linux ajanı | `dist/kontrol-linux-amd64` / `-arm64` | Kontrol edilen **Linux** bilgisayarında çalışan ajan |
| macOS ajanı | `dist/kontrol-macos-arm64` | macOS kontrolü (ekran yakalama macOS'ta sınırlıdır) |

**Neler yapabilir:** ekranı canlı izleme, dokunmatik/fare ile tıklama-dokunma-sürükleme, sağ tık, kaydırma, klavye (yumuşak klavye ile yazma), dosya yöneticisi (listeleme / indirme / yükleme / silme / klasör oluşturma), terminal (komut çalıştırma, canlı çıktı).

![Dosya yöneticisi](docs/ekran-goruntusu-dosyalar.png)

![Terminal](docs/ekran-goruntusu-terminal.png)

> ⚠️ Bu araç **yalnızca kendi cihazlarınızı** yönetmek içindir. İçinde shell çalıştırma ve dosya erişimi vardır; üretilen erişim jetonu eline geçen kişi makinenize tam yetkiyle bağlanabilir. Başkalarının cihazları için kullanmayın.

---

## 1. Hızlı başlangıç (10 dakika)

### A) Google Cloud'da iki OAuth istemcisi oluşturun

1. [console.cloud.google.com](https://console.cloud.google.com) → bir proje seçin (yoksa oluşturun).
2. **APIs & Services → OAuth consent screen**: uygulama türü *External* olsun, uygulama adı `Kontrol`, e-posta olarak kendi adresinizi girin. Test kullanıcıları bölümüne kendi Gmail adresinizi ekleyin.
3. **Credentials → Create credentials → OAuth client ID**:
   - **Application type: Desktop app** → *Client ID* ve *Client secret*'ı not alın → **Bilgisayar** için.
   - **Application type: Android** → *Client ID* ve *Client secret*'ı not alın → **Telefon** için.
     - Package name: `app.kontrol.client`
     - Signing key SHA-1: `87c7b54978c7924babb4d662a6ea6587be643cf6`
     - (Android istemcisinde "Authorized redirect URIs" alanı varsa `kontrol://oauth2redirect` yazın.)
4. Desktop istemcinin **Authorized redirect URIs** satırına `http://127.0.0.1:8765/oauth/callback` yazın.

### B) Bilgisayarınıza ajanı kurun (Linux)

```bash
# 1) ekran yakalama ve girdi için gerekli araçlar
sudo apt update
sudo apt install -y ffmpeg xdotool        # Debian/Ubuntu
# Fedora: sudo dnf install ffmpeg xdotool
# Arch:   sudo pacman -S ffmpeg xdotool

# 2) ajanı çalıştırın
sudo install -m 755 kontrol-linux-amd64 /usr/local/bin/kontrol
kontrol setup     # Google Client ID / Secret bilgilerini girin
kontrol login     # tarayıcı açılır, Google hesabınızla giriş yapın
kontrol serve     # ajanı başlatın
```

`kontrol serve` çalışırken şuna benzer bir ekran göreceksiniz:

```
  Kontrol Ajanı v1.0.0
  Bilgisayar   : ev-pc (192.168.1.20)
  Panel        : http://192.168.1.20:8765/
  Google       : siz@gmail.com
  Eşleştirme   : K7PM-3QRT
  Ekran        : 1920x1080
  Girdi        : xdotool
```

### C) Telefonda eşleştirin

1. `dist/Kontrol.apk` dosyasını telefona gönderin ve kurun (bilinmeyen kaynak izni gerekebilir).
2. Uygulamada **☰** düğmesine basıp şunları girin:
   - **Android OAuth Client ID** → Google'dan aldığınız Android istemci kimliği
   - **Android OAuth Client Secret** → Android istemcisinin secret'ı
   - **Eşleştirme kodu** → bilgisayar ekranındaki kod (ör. `K7PM-3QRT`)
   - **Kaydet**
3. Üstteki sunucu alanına bilgisayarın adresini yazın: `192.168.1.20:8765` → **Bağlan**
4. **Google** düğmesine basın → telefonun tarayıcısında Google giriş ekranı açılır → giriş yapın → tarayıcı `kontrol://oauth2redirect` ile uygulamaya döner → eşleştirme tamamlanır.
   - Google hesabı gerekmiyorsa **Kod** düğmesine basıp sadece eşleştirme kodunu kullanabilirsiniz (Google'suz mod).

Artık telefondan bilgisayarınızı görüp kontrol edebilirsiniz. 🎉

---

## 2. Arayüz nasıl kullanılır

| Düğme | İşlev |
|---|---|
| **Sağ** | Son dokunulan noktada sağ tık (bağlam menüsü) |
| **Dosya** | Dosya yöneticisi: klasöre gir, dosya indir, dosya yükle, sil, klasör oluştur |
| **Term** | Terminal: komut yazın, çıktıyı canlı izleyin |
| **⌨** | Klavyeyi açar (telefonda yumuşak klavye ile PC'ye yazarsınız) |

Dokunmatik davranışı: **tek dokunuş** = tıklama, **basılı tutup sürükleme** = sürükleme (seçim), **iki parmakla kaydırma** dikey kaydırma. Fare tekerleği dokunmatik cihazda yoktur; kaydırmak için dokunup bırakın.

---

## 3. Güvenlik

- Her bağlantı benzersiz bir **jeton** ile doğrulanır; jeton olmadan bağlanılamaz.
- Eşleştirme kodu **tek kullanımlıktır**: her eşleştirmeden sonra yenisi üretilir ve ekrana yazdırılır.
- Ajandan `kontrol devices` ile bağlı cihazları, `kontrol revoke <id>` ile bir cihazın erişimini kesebilirsiniz.
- Tüm dosya/terminal işlemleri `~/.config/kontrol/audit.log` dosyasına yazılır.
- **İnternetten erişim** istiyorsanız düz açık port yerine VPN kullanın: *Tailscale*, *ZeroTier* veya *WireGuard*. Ajanın varsayılan olarak `0.0.0.0:8765` üzerinden açık gelir; internete maruz bırakmayın ya da güvenlik duvarıyla sınırlayın.

### Google modu (önerilen)

`kontrol login` ile bir Google hesabı bağlandığında ajan **"google"** moduna geçer: eşleştirme yalnızca aynı Google hesabıyla yapılabilir. `kontrol trust <android-client-id>` ile hangi OAuth istemcisinin eşleştirebileceğini de kısıtlarsınız.

---

## 4. Servis olarak çalıştırma (Linux)

```bash
kontrol service
systemctl --user daemon-reload
systemctl --user enable --now kontrol.service
journalctl --user -u kontrol -f      # logları izleyin
```

---

## 5. Sık karşılaşılan sorunlar

| Belirti | Sebep / Çözüm |
|---|---|
| Ekran gelmiyor, siyah kalıyor | `ffmpeg` kurulu değil ya da `DISPLAY` tanımlı değil. `echo $DISPLAY` → boşsa Wayland oturumundasınız. `sudo apt install ffmpeg` ve `export DISPLAY=:0` deneyin. |
| Tıklama çalışmıyor | `xdotool` kurulu değil ya da Wayland'sınız. `sudo apt install xdotool`. Wayland'da `ydotool` gerekir (uinput + root). |
| "Eşleştirme kodu hatalı" | Kod her eşleştirmeden sonra değişir; ekrandaki güncel kodu kullanın. |
| "bu OAuth istemcisi güvenilir değil" | `kontrol trust <android-client-id>` çalıştırın. |
| Google girişi açılmıyor | Redirect URI `http://127.0.0.1:8765/oauth/callback` olarak kayıtlı mı kontrol edin. |
| APK "uygulama yüklenemiyor" | Bilinmeyen kaynaklardan yükleme iznini açın veya `adb install dist/Kontrol.apk` kullanın. |
| Telefonda "Bağlan" cevap vermiyor | Aynı ağda mısınız? `ping 192.168.1.20` ve `curl http://192.168.1.20:8765/api/status` deneyin. |

---

## 6. Kaynak koddan derleme

```bash
# Ajan (Go 1.21+)
cd agent
go build -o ../dist/kontrol-linux-amd64 .
GOOS=windows GOARCH=amd64 go build -o ../dist/kontrol-windows-amd64.exe .

# APK (JDK 17 + Android SDK 34 gerekli)
cd android
JAVA_HOME=/opt/jdk ANDROID_HOME=/opt/android-sdk ./build.sh
```

Kaynak düzeni:

```
agent/     Go ajanı (sunucu, ekran yakalama, girdi, dosya, terminal, Google OAuth)
  ui/      Web arayüzü (aynı kod APK içinde de kullanılır)
android/   Android uygulaması (Java, WebView tabanlı)
dist/      Derlenmiş teslimatlar
```

---

## 7. Yetki ve kullanım notu

Kontrol, cihazınızın **kendi** sahibi olarak kullandığınız, açıkça yetki verdiğiniz bir uzaktan erişim aracıdır. Gizli takip, izinsiz erişim veya başka birinin cihazlarını uzaktan kontrol etmek için kullanmak yasaktır ve yasal sonuçları vardır.
