# ECE — Çalışma Notları

Bu dosyaya ECE ile ayrı görüşmelerde alınan notları, kullanıcının talimatlarını ve geri bildirimleri tarih sırasıyla ekleyin.

## Görüşme kayıtları

Henüz görüşme kaydı yok.

## Kullanıcıdan gelen talimatlar

Henüz talimat kaydı yok.

## Geri bildirimler ve düzeltmeler

Henüz geri bildirim kaydı yok.

## Bekleyen sorular

Henüz bekleyen soru yok.
