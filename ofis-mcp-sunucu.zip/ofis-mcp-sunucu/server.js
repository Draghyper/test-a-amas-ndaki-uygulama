'use strict';
// Dijital Yapay Zeka Ofisi: uzak MCP sunucusu (Streamable HTTP, bağımlılık yok, Node 18+)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { execFileSync } = require('child_process');

try { for (const s of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) { const m = s.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch (e) {}
const PORT = +process.env.PORT || 8787, HOST = process.env.HOST || '127.0.0.1';
const TOKEN = process.env.OFIS_TOKEN || '';
if (TOKEN.length < 24) { console.error('OFIS_TOKEN tanımlı değil veya 24 karakterden kısa. "bash baslat.sh" ile başlat.'); process.exit(1); }
const URL_YOLU = process.env.OFIS_URL_YOLU !== '0';
const VERI = path.resolve(process.env.VERI_DIZINI || path.join(__dirname, 'veri', 'ofis'));
const OFIS = path.join(VERI, '00_OFIS');
const SURUMLER = ['2025-06-18', '2025-03-26', '2024-11-05'];
const MAX_METIN = 20000, MAX_DOSYA = 200 * 1024;

const sha = s => crypto.createHash('sha256').update(s).digest();
const tokenOk = t => typeof t === 'string' && crypto.timingSafeEqual(sha(t), sha(TOKEN));
const tarih = () => { try { return new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Istanbul' }); } catch (e) { return new Date().toISOString().slice(0, 10); } };
const git = (...a) => { try { execFileSync('git', ['-C', VERI, '-c', 'user.name=ofis', '-c', 'user.email=ofis@localhost', ...a], { stdio: 'ignore', timeout: 5000 }); return true; } catch (e) { return false; } };
if (!fs.existsSync(path.join(VERI, '.git')) && git('init')) { git('add', '-A'); git('commit', '-m', 'ilk kayit'); }
const gitKaydet = m => { git('add', '-A'); git('commit', '-m', m); };
const norm = s => String(s || '').replace(/[İI]/g, 'i').toLowerCase().replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c').trim().replace(/^\d+_/, '');
const oku = p => fs.readFileSync(p, 'utf8');
const yaz = (p, t) => { const g = p + '.tmp' + process.pid; fs.writeFileSync(g, t); fs.renameSync(g, p); };
const metin = (v, ad, maks = MAX_METIN) => { if (typeof v !== 'string' || !v.trim()) throw new Error(ad + ' boş olamaz.'); if (v.length > maks) throw new Error(ad + ' çok uzun (en fazla ' + maks + ' karakter).'); return v; };

function masalar() {
  const r = [];
  for (const d of fs.readdirSync(VERI, { withFileTypes: true })) {
    if (!d.isDirectory() || !/^\d_/.test(d.name)) continue;
    for (const m of fs.readdirSync(path.join(VERI, d.name), { withFileTypes: true }))
      if (m.isDirectory() && /^\d\d_/.test(m.name)) r.push({ dep: d.name, ad: m.name, yol: path.join(VERI, d.name, m.name) });
  }
  return r;
}
function masaBul(g) {
  const n = norm(g), l = masalar(), m = l.find(x => norm(x.ad) === n);
  if (!m) throw new Error('Bilinmeyen masa: "' + g + '". Geçerli masalar: ' + l.map(x => norm(x.ad).toUpperCase()).join(', '));
  return m;
}
const rolu = m => { try { return (oku(path.join(m.yol, 'profil_ve_gorevler.md')).split('\n')[0] || '').replace(/^#\s*/, ''); } catch (e) { return m.ad; } };

function bolumEkle(t, baslik, madde) {
  const L = t.split('\n'), i = L.findIndex(l => l.trim() === '## ' + baslik);
  if (i < 0) throw new Error('Dosyada bölüm bulunamadı: ' + baslik);
  let j = L.findIndex((l, k) => k > i && /^## /.test(l)); if (j < 0) j = L.length;
  const g = L.slice(i + 1, j).filter(l => !/^\s*Henüz /.test(l));
  while (g.length && !g[g.length - 1].trim()) g.pop();
  while (g.length && !g[0].trim()) g.shift();
  const satir = '- [' + tarih() + '] ' + madde.trim().replace(/^(\s*)#/gm, '$1\\#').replace(/\n/g, '\n  ');
  const son = L.slice(j); 
  return [...L.slice(0, i + 1), '', ...g, satir, '', ...son].join('\n').replace(/\n{3,}/g, '\n\n').replace(/\n*$/, '\n');
}

const gorevYol = path.join(OFIS, 'gorevler.json'), kararYol = path.join(OFIS, 'kararlar.json');
const jOku = (p, v) => { try { return JSON.parse(oku(p)); } catch (e) { return v; } };
const jYaz = (p, v) => { fs.mkdirSync(path.dirname(p), { recursive: true }); yaz(p, JSON.stringify(v, null, 1)); };

const OZET = () => { const dl = {}; masalar().forEach(m => (dl[m.dep] = dl[m.dep] || []).push('- ' + norm(m.ad).toUpperCase() + ' — ' + rolu(m).replace(/^.*?—\s*/, ''))); return Object.entries(dl).map(([d, l]) => d + '\n' + l.join('\n')).join('\n\n'); };
const NOT_BOLUM = ['Görüşme kayıtları', 'Kullanıcıdan gelen talimatlar', 'Geri bildirimler ve düzeltmeler', 'Bekleyen sorular'];
const PROFIL_BOLUM = ['Projeler', 'Alınan kararlar', 'Teslim edilen işler'];
const DOSYA_ADI = /^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/;
const masaS = { type: 'string', description: 'Masa adı, örn. ATLAS, KEREM, LINA, MIRA, ECE, ARYA, DENIZ, LEVENT, EREN, BARAN, RENKLI' };

const ARACLAR = [
  { ad: 'ofis_baslat', ro: 1, ac: 'Sohbetin başında çağır. ATLAS çağrı kuralları, ATLAS profili, ofis özeti, açık görevler ve son kararları tek yanıtta verir.', s: {}, fn: () => {
    const m = masaBul('ATLAS'), cagri = (() => { try { return oku(path.join(OFIS, 'ATLAS_CAGRI.txt')); } catch (e) { return '(çağrı kuralları yok)'; } })();
    const acik = jOku(gorevYol, []).filter(g => g.durum !== 'bitti').map(g => `#${g.id} [${g.durum}] (${g.masa}, ${g.oncelik}) ${g.baslik}`);
    const kar = jOku(kararYol, []).slice(-5).map(k => `[${k.tarih}] ${k.masa}: ${k.metin}`);
    return `=== ATLAS ÇAĞRI KURALLARI ===\n${cagri}\n=== ATLAS PROFİLİ ===\n${oku(path.join(m.yol, 'profil_ve_gorevler.md'))}\n=== OFİS ===\n${OZET()}\n\n=== AÇIK GÖREVLER ===\n${acik.join('\n') || '(yok)'}\n\n=== SON KARARLAR ===\n${kar.join('\n') || '(yok)'}`;
  } },
  { ad: 'ofis_ozet', ro: 1, ac: 'Departmanları ve masaları rolleriyle listeler.', s: {}, fn: () => OZET() },
  { ad: 'masa_profili_oku', ro: 1, ac: 'Bir masanın profil ve görev dosyasını okur.', s: { masa: masaS }, r: ['masa'], fn: a => oku(path.join(masaBul(a.masa).yol, 'profil_ve_gorevler.md')) },
  { ad: 'masa_notlari_oku', ro: 1, ac: 'Bir masanın çalışma notlarını okur.', s: { masa: masaS }, r: ['masa'], fn: a => oku(path.join(masaBul(a.masa).yol, 'calisma_notlari.md')) },
  { ad: 'masa_notu_ekle', ro: 0, ac: 'Masanın çalışma notlarına tarihli madde ekler. Mevcut notları silmez.', s: { masa: masaS, bolum: { type: 'string', enum: NOT_BOLUM }, metin: { type: 'string' } }, r: ['masa', 'bolum', 'metin'], fn: a => {
    if (!NOT_BOLUM.includes(a.bolum)) throw new Error('bolum şunlardan biri olmalı: ' + NOT_BOLUM.join(', '));
    const m = masaBul(a.masa), p = path.join(m.yol, 'calisma_notlari.md');
    yaz(p, bolumEkle(oku(p), a.bolum, metin(a.metin, 'metin'))); gitKaydet('not: ' + m.ad); return 'Not eklendi: ' + m.ad + ' / ' + a.bolum;
  } },
  { ad: 'profil_kaydi_ekle', ro: 0, ac: 'Profilde SADECE Projeler, Alınan kararlar ve Teslim edilen işler bölümlerine tarihli madde ekler. Profilin diğer bölümleri değiştirilemez.', s: { masa: masaS, bolum: { type: 'string', enum: PROFIL_BOLUM }, metin: { type: 'string' } }, r: ['masa', 'bolum', 'metin'], fn: a => {
    if (!PROFIL_BOLUM.includes(a.bolum)) throw new Error('bolum şunlardan biri olmalı: ' + PROFIL_BOLUM.join(', '));
    const m = masaBul(a.masa), p = path.join(m.yol, 'profil_ve_gorevler.md'), t = metin(a.metin, 'metin');
    yaz(p, bolumEkle(oku(p), a.bolum, t));
    if (a.bolum === 'Alınan kararlar') { const k = jOku(kararYol, []); k.push({ tarih: tarih(), masa: norm(m.ad).toUpperCase(), metin: t.slice(0, 500) }); jYaz(kararYol, k); }
    gitKaydet('profil: ' + m.ad); return 'Kayıt eklendi: ' + m.ad + ' / ' + a.bolum;
  } },
  { ad: 'gorev_olustur', ro: 0, ac: 'Yeni görev kaydı açar.', s: { baslik: { type: 'string' }, aciklama: { type: 'string' }, masa: masaS, oncelik: { type: 'string', enum: ['dusuk', 'orta', 'yuksek'] } }, r: ['baslik', 'masa'], fn: a => {
    const m = masaBul(a.masa), l = jOku(gorevYol, []), g = { id: l.reduce((x, y) => Math.max(x, y.id), 0) + 1, baslik: metin(a.baslik, 'baslik', 200), aciklama: a.aciklama ? metin(a.aciklama, 'aciklama') : '', masa: norm(m.ad).toUpperCase(), oncelik: ['dusuk', 'orta', 'yuksek'].includes(a.oncelik) ? a.oncelik : 'orta', durum: 'acik', tarih: tarih(), notlar: [] };
    l.push(g); jYaz(gorevYol, l); gitKaydet('gorev ' + g.id); return 'Görev açıldı: #' + g.id;
  } },
  { ad: 'gorev_listele', ro: 1, ac: 'Görevleri listeler (isteğe bağlı durum ve masa filtresi).', s: { durum: { type: 'string', enum: ['acik', 'devam', 'bekliyor_onay', 'bitti'] }, masa: masaS }, fn: a => {
    const mk = a.masa ? norm(masaBul(a.masa).ad).toUpperCase() : null;
    const l = jOku(gorevYol, []).filter(g => (!a.durum || g.durum === a.durum) && (!mk || g.masa === mk));
    return l.map(g => `#${g.id} [${g.durum}] (${g.masa}, ${g.oncelik}, ${g.tarih}) ${g.baslik}${g.aciklama ? '\n   ' + g.aciklama : ''}${g.notlar.length ? '\n   notlar: ' + g.notlar.join(' | ') : ''}`).join('\n') || 'Görev yok.';
  } },
  { ad: 'gorev_guncelle', ro: 0, ac: 'Görevin durumunu günceller, isteğe bağlı not ekler.', s: { id: { type: 'integer' }, durum: { type: 'string', enum: ['acik', 'devam', 'bekliyor_onay', 'bitti'] }, not: { type: 'string' } }, r: ['id', 'durum'], fn: a => {
    if (!['acik', 'devam', 'bekliyor_onay', 'bitti'].includes(a.durum)) throw new Error('Geçersiz durum.');
    const l = jOku(gorevYol, []), g = l.find(x => x.id === a.id); if (!g) throw new Error('Görev bulunamadı: #' + a.id);
    g.durum = a.durum; if (a.not) g.notlar.push('[' + tarih() + '] ' + metin(a.not, 'not', 1000)); jYaz(gorevYol, l); gitKaydet('gorev ' + g.id); return 'Güncellendi: #' + g.id + ' → ' + g.durum;
  } },
  { ad: 'cikti_kaydet', ro: 0, ac: 'Masanın ofis-ciktilari klasörüne YENİ bir dosya yazar. Aynı ad varsa üzerine yazmaz, _v2, _v3 ekler. Uzantı: .md .txt .json .csv', s: { masa: masaS, dosya_adi: { type: 'string' }, icerik: { type: 'string' } }, r: ['masa', 'dosya_adi', 'icerik'], fn: a => {
    const m = masaBul(a.masa), ad = a.dosya_adi;
    if (!DOSYA_ADI.test(ad) || !/\.(md|txt|json|csv)$/i.test(ad)) throw new Error('Geçersiz dosya adı. Harf, rakam, . _ - kullan; uzantı .md .txt .json .csv olsun.');
    if (typeof a.icerik !== 'string' || !a.icerik.length) throw new Error('icerik boş olamaz.');
    if (Buffer.byteLength(a.icerik) > MAX_DOSYA) throw new Error('Dosya 200 KB sınırını aşıyor.');
    const dir = path.join(m.yol, 'ofis-ciktilari', tarih()); fs.mkdirSync(dir, { recursive: true });
    const ek = path.extname(ad), taban = ad.slice(0, -ek.length); let son = ad, n = 2;
    while (fs.existsSync(path.join(dir, son))) son = taban + '_v' + (n++) + ek;
    fs.writeFileSync(path.join(dir, son), a.icerik, { flag: 'wx' }); gitKaydet('cikti: ' + m.ad + '/' + son);
    return 'Kaydedildi: ' + norm(m.ad).toUpperCase() + '/' + tarih() + '/' + son;
  } },
  { ad: 'cikti_listele', ro: 1, ac: 'Masaların çıktı dosyalarını listeler (masa verilmezse hepsi).', s: { masa: masaS }, fn: a => {
    const l = a.masa ? [masaBul(a.masa)] : masalar(), r = [];
    for (const m of l) { const k = path.join(m.yol, 'ofis-ciktilari'); if (!fs.existsSync(k)) continue;
      for (const t of fs.readdirSync(k)) { if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) continue; for (const f of fs.readdirSync(path.join(k, t))) r.push(`${norm(m.ad).toUpperCase()} ${t}/${f} (${fs.statSync(path.join(k, t, f)).size} bayt)`); } }
    return r.slice(-100).join('\n') || 'Çıktı yok.';
  } },
  { ad: 'cikti_oku', ro: 1, ac: 'Bir çıktı dosyasını okur. yol örn: 2026-11-21/senaryo.md', s: { masa: masaS, yol: { type: 'string' } }, r: ['masa', 'yol'], fn: a => {
    if (!/^\d{4}-\d{2}-\d{2}\/[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(a.yol || '')) throw new Error('yol biçimi: YYYY-AA-GG/dosya.md');
    const m = masaBul(a.masa), p = path.join(m.yol, 'ofis-ciktilari', a.yol), st = fs.lstatSync(p);
    if (!st.isFile() || st.isSymbolicLink()) throw new Error('Dosya okunamaz.'); return oku(p);
  } },
];

const ok = (id, result) => ({ jsonrpc: '2.0', id, result }), hata = (id, code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });
function rpc(q, ip) {
  if (!q || q.jsonrpc !== '2.0' || typeof q.method !== 'string') return hata(q && q.id !== undefined ? q.id : null, -32600, 'Geçersiz istek');
  const { id, method, params } = q;
  if (id === undefined || method.startsWith('notifications/')) return null;
  if (method === 'initialize') return ok(id, { protocolVersion: SURUMLER.includes(params && params.protocolVersion) ? params.protocolVersion : SURUMLER[0], capabilities: { tools: {} }, serverInfo: { name: 'dijital-ofis', version: '1.0.0' }, instructions: 'Dijital Yapay Zeka Ofisi. Sohbetin başında ofis_baslat aracını çağır. Hiçbir şeyi silme, yayınlama veya gönderme.' });
  if (method === 'ping') return ok(id, {});
  if (method === 'tools/list') return ok(id, { tools: ARACLAR.map(t => ({ name: t.ad, description: t.ac, inputSchema: { type: 'object', properties: t.s, required: t.r || [] }, annotations: t.ro ? { readOnlyHint: true } : { readOnlyHint: false, destructiveHint: false, idempotentHint: false } })) });
  if (method === 'tools/call') {
    const t = ARACLAR.find(x => x.ad === (params && params.name));
    if (!t) return hata(id, -32602, 'Bilinmeyen araç');
    console.log(new Date().toISOString(), ip, 'tool', t.ad);
    try { return ok(id, { content: [{ type: 'text', text: String(t.fn((params && params.arguments) || {})) }] }); }
    catch (e) { return ok(id, { isError: true, content: [{ type: 'text', text: 'Hata: ' + e.message }] }); }
  }
  return hata(id, -32601, 'Yöntem bulunamadı');
}

const sayac = new Map();
const hizOk = ip => { const k = Math.floor(Date.now() / 60000), v = sayac.get(ip); if (!v || v.k !== k) { sayac.set(ip, { k, c: 1 }); return true; } return ++v.c <= 120; };
setInterval(() => { const k = Math.floor(Date.now() / 60000); for (const [ip, v] of sayac) if (v.k < k) sayac.delete(ip); }, 60000).unref();

http.createServer((req, res) => {
  const u = req.url.split('?')[0], ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const bitir = (c, h) => { res.writeHead(c, h || {}); res.end(); };
  if (req.method === 'GET' && u === '/saglik') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  let yetkili = false, yol = u;
  const m = u.match(/^\/s\/([A-Za-z0-9_-]{1,200})\/mcp$/);
  if (m) { if (!URL_YOLU) return bitir(404); yetkili = tokenOk(m[1]); yol = '/mcp'; }
  else { const a = req.headers.authorization || ''; yetkili = a.startsWith('Bearer ') && tokenOk(a.slice(7)); }
  if (yol !== '/mcp') return bitir(404);
  if (!yetkili) return bitir(401, { 'WWW-Authenticate': 'Bearer' });
  if (!hizOk(ip)) return bitir(429);
  if (req.method !== 'POST') return bitir(405, { Allow: 'POST' });
  let b = '', iptal = false;
  req.on('data', d => { b += d; if (b.length > 1e6 && !iptal) { iptal = true; bitir(413); req.destroy(); } });
  req.on('end', () => {
    if (iptal) return;
    let q; try { q = JSON.parse(b); } catch (e) { res.writeHead(400, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(hata(null, -32700, 'Geçersiz JSON'))); }
    const yanit = Array.isArray(q) ? q.map(x => rpc(x, ip)).filter(Boolean) : rpc(q, ip);
    if (!yanit || (Array.isArray(yanit) && !yanit.length)) return bitir(202);
    res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(yanit));
  });
}).listen(PORT, HOST, () => console.log(`Ofis MCP sunucusu: http://${HOST}:${PORT}/mcp (HTTPS için ters vekil gerekir)`));
