#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js 18 veya üstü gerekli."; exit 1; }
if [ ! -f .env ]; then
  T=$(node -e "console.log(require('crypto').randomBytes(24).toString('hex'))")
  printf 'OFIS_TOKEN=%s\nPORT=8787\n' "$T" > .env; chmod 600 .env
  echo "TOKEN OLUŞTURULDU (sadece şimdi gösteriliyor, bir yere sakla): $T"
fi
exec node server.js
