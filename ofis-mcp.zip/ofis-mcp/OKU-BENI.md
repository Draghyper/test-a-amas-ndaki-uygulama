# Dijital Ofis MCP - Kurulum (Linux)

1. Zip'i ac:  unzip ofis-mcp.zip -d ~ && cd ~/ofis-mcp
2. Kur (bir kere):  npm install
3. Calistir:  node server.js
   Ekranda "Yerel adres" yazar. Sonundaki /mcp/XXXX kismi gizli anahtarin.
4. Baska bir terminal sekmesinde tunel ac (cloudflared kurulu olmali):
   cloudflared tunnel --url http://127.0.0.1:4747
   Cikan https://....trycloudflare.com adresini kopyala.
5. Claude'a eklenecek adres:  https://....trycloudflare.com/mcp/XXXX
6. Claude > Ayarlar > Baglayicilar (Connectors) > Ozel baglayici ekle > adresi yapistir.
7. Yeni sohbette yaz:  ofisi baslat, gorev: ...

Notlar:
- Bilgisayar ve iki terminal acik oldugu surece calisir.
- Tunel adresi her acilista degisir; Claude'daki baglayiciyi guncellemen gerekir.
- /mcp/XXXX gizli anahtardir, kimseyle paylasma.
- Dosyalar ofis-ciktilari klasorune kaydedilir.
